from sitemapgen import cli
cli.run()